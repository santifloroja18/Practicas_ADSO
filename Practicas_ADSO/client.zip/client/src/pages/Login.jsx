

export default function Login(){
    return(
        <div>
            HOLA
        </div>
    )
}