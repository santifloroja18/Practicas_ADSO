

export default function Registro(){
    return(
        <div>
            
        </div>
    )
}